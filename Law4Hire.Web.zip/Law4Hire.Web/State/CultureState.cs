﻿using Microsoft.AspNetCore.Localization;
using Microsoft.JSInterop;
using System.Globalization;

namespace Law4Hire.Web.State;

public class CultureState
{
    private readonly IJSRuntime _jsRuntime;

    public CultureInfo CurrentCulture { get; private set; } = new("en-US");

    // Event that components can subscribe to, to know when the state changes.
    public event Action? OnChange;
    public void SetCultureFromCookie(IHttpContextAccessor httpContextAccessor)
    {
        var cookie = httpContextAccessor.HttpContext?.Request.Cookies[CookieRequestCultureProvider.DefaultCookieName];
        if (!string.IsNullOrWhiteSpace(cookie))
        {
            var requestCulture = CookieRequestCultureProvider.ParseCookieValue(cookie);
            if (requestCulture != null)
            {
                //CultureInfo.DefaultThreadCurrentCulture = new CultureInfo(requestCulture.Cultures[0].Value ?? "en-US");
                CultureInfo.DefaultThreadCurrentUICulture = new CultureInfo(requestCulture.UICultures[0].Value ?? "en-US");

            }
        }
    }
    public CultureState(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    // Sets the new culture and saves it to the browser's local storage.
    public async Task SetCultureAsync(string cultureCode)
    {
        CurrentCulture = new CultureInfo(cultureCode);
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", "blazorCulture", cultureCode);
        NotifyStateChanged();
    }

    // Initializes the culture from local storage when the app starts.
    public async Task InitializeCultureAsync()
    {
        var cultureCode = await _jsRuntime.InvokeAsync<string>("localStorage.getItem", "blazorCulture");
        if (!string.IsNullOrEmpty(cultureCode))
        {
            CurrentCulture = new CultureInfo(cultureCode);
        }
        NotifyStateChanged();
    }

    private void NotifyStateChanged() => OnChange?.Invoke();
}