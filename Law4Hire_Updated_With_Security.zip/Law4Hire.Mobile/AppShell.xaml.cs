﻿namespace Law4Hire.Mobile;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
