﻿namespace Law4Hire.Core.Enums;

public enum PackageType
{
    SelfRepresentationWithParalegal = 1,
    HybridWithAttorneyOverview = 2,
    FullRepresentationStandard = 3,
    FullRepresentationGuaranteed = 4
}